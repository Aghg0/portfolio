import serial
import time
import datetime
import speech_recognition as sr
from playsound import playsound

try:
  ser = serial.Serial('COM4', 9600)
except:
  ser = serial.Serial('COM3', 9600)

time.sleep(1.75)



def follow_up_attack():
  r = sr.Recognizer()
  while ser.inWaiting() == 0:
    with sr.Microphone() as source:
      print("Say something!")
      audio = r.listen(source)
      eng = r.recognize_whisper(audio, language="english")
      print(eng)
      if "WATCH YOUR HEAD" in eng.upper() or "ALL IN " in eng.upper() or "SWITCH" in eng.upper():
          if "ALL IN" in eng.upper():
            playsound(str("d:\Downloads\Projects\Aventurine\ALL_IN.mp3"))
            ser.write(str(0).encode())
          elif "WATCH YOUR HEAD" in eng.upper():
            playsound(str("d:\Downloads\Projects\Aventurine\Watch_your_head.mp3"))
            ser.write(str(0).encode())
          elif "SWITCH" in eng.upper():
            playsound(str("d:\Downloads\Projects\Aventurine\Switch.mp3"))
            ser.write(str(1).encode())
            print ("TEST STR " + str(1))
          time.sleep(2)

def alarm():
  print('What time shall you wake (Enter in the form of HOUR:MINUTE AM/PM):')
  alarm_time = input()
  if "SWITCH" in alarm_time.upper():
     ser.write(str(1).encode())
  else:
    hour = alarm_time[0:alarm_time.find(':')]
    if 'PM' in alarm_time:
        if str(hour) != "12":
            hour = int(hour)+12
    if 'A' in alarm_time and str(hour) == "12":
        hour = "00"
    if len(hour) == 1:
      hour = '0' + str(hour)
    minute = alarm_time[alarm_time.find(':')+1:alarm_time.find(':')+3]
    print(hour)
    print(minute)
    trigger=False
    days = []
    while ser.inWaiting() == 0:
        today = datetime.datetime.now()
        print(today)
        if today.strftime("%H") == str(hour) and today.strftime("%M") == str(minute):
            if len(days) == 0:
              days.append(today)
              playsound(str("d:\Downloads\Projects\Aventurine\Watch_your_head.mp3"))
              ser.write(str(0).encode())  
            elif int(divmod((today - days[-1]).days * 24 * 60 * 60 + (today - days[-1]).seconds, 60)[0]) > 1:
              days.append(today)
              playsound(str("d:\Downloads\Projects\Aventurine\Watch_your_head.mp3"))
              ser.write(str(0).encode())

while True:
  if ser.inWaiting() != 0:
    result = ser.read()
    print(result)
    print(ser.inWaiting())
    if result == b'\x01':
      playsound(str("d:\Downloads\Projects\Aventurine\Attack.mp3"))
      follow_up_attack()
    elif result == b'\x00':
      playsound(str("d:\Downloads\Projects\Aventurine\Alarm.mp3"))
      alarm()