import miku
import wav_splitter
import wav_to_rgbs
import urllib.request
import requests
from PIL import Image
import io
import re
import os
import math


def setup(item):
    cnt = -1
    perm_cnt = False
    for o in reversed(item):
        if not o.isalnum():
            perm_cnt = True
        if perm_cnt == False:
            cnt -= 1
    extension = item[cnt:]
    filename = item.replace(extension, "")

    file_path = os.path.join("New folder (3)", "miku_color_song",filename + ".txt")
    if not os.path.exists(file_path):
        src = miku.extract_src(filename)
        red,green,blue,red2,green2,blue2 = miku.src_to_color(src,filename)

        file_path = os.path.join("New folder (3)", "miku_color_song",filename + ".txt")
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w") as file1:
            file1.write(str(int(red))+"r"+str(int(green))+"g"+str(int(blue))+"b")
        
        file_path2 = os.path.join("New folder (3)", "miku_color_song",filename+"2.txt")
        os.makedirs(os.path.dirname(file_path2), exist_ok=True)
        with open(file_path2, "w") as file2:
            file2.write(str(int(red2))+"r"+str(int(green2))+"g"+str(int(blue2))+"b")
        print("File created or overwritten successfully.")
    if not os.path.exists("D:/Downloads/New folder (3)/song_separate/"+filename+"harmonic.wav"):
        wav_splitter.wav_split("D:/Downloads/New folder (3)/song"+"/"+item)

    if not os.path.exists(os.path.join("New folder (3)", "arduino_rgb", filename +"harmonic.txt")):
        wav_to_rgbs.harmonic_to_rgbs("D:/Downloads/New folder (3)/song_separate/"+filename+"harmonic.wav",15)
        wav_to_rgbs.percussive_to_rgbs("D:/Downloads/New folder (3)/song_separate/"+filename+"percussive.wav",15)


if __name__ == "__main__":
    # setup("heartforecasteve.wav")
    for item in os.listdir("D:/Downloads/New folder (3)/song"):
        setup(item)