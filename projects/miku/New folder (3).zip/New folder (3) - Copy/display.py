
# Pack the buttons vertically
from tkinter import *
from PIL import Image, ImageTk
import yt_to_wav
import miku_setup
import threading
import os
import miku_run
import random


root = Tk()
root.title("Title")
root.geometry('750x500')
end = False
def resize_image(event):
    new_width = event.width
    new_height = event.height
    print(new_height)
    image = copy_of_image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    label.config(image = photo)
    label.image = photo #avoid garbage collection
    button.place(x=int(new_width/2),y=int(new_height/2),anchor='c')
    button.config(height=1,width=10,font=('Consolas 20 bold'))
    button2.place(x=int(new_width/2),y=int(new_height/2+new_height/4),anchor='c')
    button2.config(height=1,width=10,font=('Consolas 20 bold'))
    button3.place(x=int(new_width/2),y=int(new_height/4),anchor='c')
    button3.config(height=1,width=10,font=('Consolas 20 bold'))

def add_button():
    button.config(state="disabled")
    button2.config(state="disabled")
    button3.config(state="disabled")
    add_window = Tk()
    add_window.geometry('600x50')
    add_entry = Entry(add_window)
    add_entry.config(width=55)
    
    add_label = Label(add_window,text="Song URL (Press Enter to Submit Both)")

    name_label = Label(add_window,text="Name (Press Enter to Submit Both)")

    name_entry = Entry(add_window)
    name_entry.config(width=55)

    add_window.columnconfigure(0, weight=1)
    add_window.columnconfigure(1, weight=1)
    add_label.grid(row=0, column=0)
    add_entry.grid(row=0, column=1)
    name_label.grid(row=1,column=0)
    name_entry.grid(row=1,column=1)

    def song_url(event):
        song_url = add_entry.get()
        name = name_entry.get()
        name = name.replace(" ","_")
        print(name)
        def yt_to_wav_to_setup(song_url,name):
            try:
                yt_to_wav.download_youtube_content(song_url,name)
                miku_setup.setup(name+".wav")
                # print("hi")
                global success
                success = "Completed successfully"
                # return True
            except:
                success = "Failed"

        def confirm_label():
            confirm_label = Label(confirm_window,text="Please Wait")
            confirm_label.pack()
            confirm_window.update()
            global done
            done = True

        confirm_window = Tk()
        confirm_window.geometry("200x150")
        confirm_window.after(100, confirm_label())
        confirm_window.after(200,add_entry.config(state="disabled"))
        confirm_window.after(200,name_entry.config(state="disabled"))
        if done == True:
            yt_to_wav_to_setup(song_url,name)
        if len(success) != 0:
            add_entry.config(state="normal")
            name_entry.config(state="normal")
            add_entry.delete(0, END)
            name_entry.delete(0, END)
            confirm_window.destroy()
            result = Tk()
            result.geometry("200x150")
            result_label = Label(result,text=success).pack()
        confirm_window.mainloop()
        # confirm_window.mainloop()
    add_window.bind("<Return>",song_url)

    def add_close(event):
        button.config(state="active")
        button2.config(state="active")
        button3.config(state="active")

    add_window.bind("<Destroy>",add_close)
    # window.protocol("WM_DELETE_WINDOW", add_close)
    add_window.mainloop()

def song_button():
    button.config(state="disabled")
    button2.config(state="disabled")
    button3.config(state="disabled")
    song_window = Toplevel()
    song_window.geometry('350x400')


    def onFrameConfigure(canvas):
        '''Reset the scroll region to encompass the inner frame'''
        canvas.configure(scrollregion=canvas.bbox("all"))

    canvas = Canvas(song_window, borderwidth=0,background="#ffffff")
    frame = Frame(canvas, background="#ffffff")
    vsb = Scrollbar(song_window, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vsb.set)

    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    canvas.create_window((4,4), window=frame, anchor="nw")

    frame.bind("<Configure>", lambda event, canvas=canvas: onFrameConfigure(canvas))

    listnumber = 1
    for item in os.listdir("D:/Downloads/New folder (3)/song"):

        with open("D:/Downloads/New folder (3)/miku_color_song/"+item[0:len(item)-4]+".txt") as color:
            rgb =color.readline()
            red = rgb[0:rgb.index("r")]
            green = rgb[rgb.index("r")+1:rgb.index("g")]
            blue = rgb[rgb.index("g")+1:rgb.index("b")]
            red = hex(int(red))[2:]
            green = hex(int(green))[2:]
            blue = hex(int(blue))[2:]

        base_width = 75
        print(item[0:len(item)-4]+".jpg")
        img = Image.open("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")
        wpercent = (base_width / float(img.size[0]))
        hsize = int((float(img.size[1]) * float(wpercent)))
        img = img.resize((base_width, hsize), Image.Resampling.LANCZOS)
        img.save("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")

        image_icon = Image.open("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")
        photo_icon = ImageTk.PhotoImage(image_icon)


        label = Label(frame, 
                image=photo_icon, 
                text=(item[0:len(item)-4]).replace("_"," "), 
                compound=LEFT,padx=10)
        label.image = photo_icon
        label.config(height=80,width=350,font=('Consolas 12 bold'),bg="#"+str(red)+str(green)+str(blue))
        # label = Label(frame,text=item,font=("Consolas, 16"))
        label.grid(row=listnumber)
        listnumber += 1

    def song_close(event):
        button.config(state="active")
        button2.config(state="active")
        button3.config(state="active")

    song_window.bind("<Destroy>",song_close)
    
    song_window.mainloop()

def play_button():        
    label.destroy()
    button_x = button.winfo_x()
    button1_y = button.winfo_y()
    button2_y = button2.winfo_y()
    button3_y = button3.winfo_y()
    button.destroy()
    button2.destroy()
    button3.destroy()
    miku_run.stop = False
    miku_run.pause = False

    def skip_button():
        miku_run.pause = False
        miku_run.skip = True
        button_resume.config(text="Pause")
    global end
    end = False
    def stop_button():
        global end
        end = True
        miku_run.stop = True
        miku_run.pause = False
        button_stop.place_forget()
        button_resume.place_forget()
        global label_icon
        label_icon.destroy()

        global image
        image = Image.open('D:/Downloads/New folder (3)/tkinterbg.png')
        copy_of_image = image.copy()
        global photo
        photo = ImageTk.PhotoImage(image)
        global label
        label = Label(root, image = photo)
        label.image = photo
        label.bind('<Configure>', resize_image)
        label.pack(fill=BOTH, expand = YES)

        global button
        button = Button(root,text="Add",font=('Consolas 20 bold'),command=add_button)
        global button2
        button2 = Button(root,text="Songs",font=('Consolas 20 bold'),command=song_button)
        global button3
        button3 = Button(root,text="Play",font=('Consolas 20 bold'),command=play_button)

        button.place(x=button_x,y=button1_y)
        button.config(height=1,width=10,font=('Consolas 20 bold'))
        button2.place(x=button_x,y=button2_y)
        button2.config(height=1,width=10,font=('Consolas 20 bold'))
        button3.place(x=button_x,y=button3_y)
        button3.config(height=1,width=10,font=('Consolas 20 bold'))

        
        
        

    def resume_button():
        miku_run.pause = not miku_run.pause
        if miku_run.pause == True:
            button_resume.config(text="Resume")
        else:
            button_resume.config(text="Pause")

    button_skip = Button(root,text="Skip",font=('Consolas 20 bold'),command=skip_button)
    button_skip.place(relx=0.5, rely=0.5, anchor=CENTER)
    button_skip.config(height=1,width=10,font=('Consolas 20 bold'))
    button_stop = Button(root,text="Stop",font=('Consolas 20 bold'),command=stop_button)
    button_stop.place(relx=0.5, rely=0.75, anchor=CENTER)
    button_stop.config(height=1,width=10,font=('Consolas 20 bold'))    
    button_resume = Button(root,text="Pause",font=('Consolas 20 bold'),command=resume_button)
    button_resume.place(relx=0.5, rely=0.25, anchor=CENTER)
    button_resume.config(height=1,width=10,font=('Consolas 20 bold'))

    def song_play():

        song_list =[]
        for item in os.listdir("D:/Downloads/New folder (3)/song"):
            song_list.append(item)
        while len(song_list) != 0 and end == False:
            item = song_list[random.randint(0, len(song_list)-1)]
            song_list.remove(item)
            with open("D:/Downloads/New folder (3)/miku_color_song/"+item[0:len(item)-4]+".txt") as color:
                rgb =color.readline()
            red = rgb[0:rgb.index("r")]
            green = rgb[rgb.index("r")+1:rgb.index("g")]
            blue = rgb[rgb.index("g")+1:rgb.index("b")]
            red = hex(int(red))[2:]
            green = hex(int(green))[2:]
            blue = hex(int(blue))[2:]
            root.config(bg="#"+str(red)+str(green)+str(blue))

            base_width = 75
            img = Image.open("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")
            wpercent = (base_width / float(img.size[0]))
            hsize = int((float(img.size[1]) * float(wpercent)))
            img = img.resize((base_width, hsize), Image.Resampling.LANCZOS)
            img.save("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")

            image_icon = Image.open("D:/Downloads/New folder (3)/picture/"+item[0:len(item)-4]+".jpg")
            photo_icon = ImageTk.PhotoImage(image_icon)

            global label_icon
            label_icon = Label(root, 
                    image=photo_icon, 
                    text=(item[0:len(item)-4]).replace("_"," "), 
                    compound=LEFT,padx=10)
            label.image = photo_icon
            label_icon.place(relx=0.5, rely=0.9, anchor=CENTER)
            label_icon.config(height=80,width=500,font=('Consolas 15 bold'),bg="#"+str(red)+str(green)+str(blue))
            root.update()
            miku_run.run(item)
            # time.sleep(1)
    # song_play()
    t1 = threading.Thread(target=song_play)
    t1.start()


global image
image = Image.open('D:/Downloads/New folder (3)/tkinterbg.png')
copy_of_image = image.copy()
photo = ImageTk.PhotoImage(image)
label = Label(root, image = photo)
label.image = photo
label.bind('<Configure>', resize_image)
label.pack(fill=BOTH, expand = YES)


button = Button(root,text="Add",font=('Consolas 20 bold'),command=add_button)
button2 = Button(root,text="Songs",font=('Consolas 20 bold'),command=song_button)
button3 = Button(root,text="Play",font=('Consolas 20 bold'),command=play_button)



root.mainloop()