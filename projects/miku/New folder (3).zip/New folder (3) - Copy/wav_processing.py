# brightness - based on absolute loudest amplitdue
    # go through wav, find loudest and quiestest = 0. set loud = 255, quiet = 0
    # brightness of everything else is a frac - ampl / abs ampl * 255
# top one color, bottom one color bc im too lazy lmao
# top top one color maybe? top bottom one color?
    # sep via - avg based on fll song - each frame weighted avg?, avg the weighted avgs?
    # top top , top bottom have diff brightness / color
    # color - top bottom = top top shifted down? - least of rgb val / 2 mb?
    # color -  asso w/ loudest freq? - another frac thing
#bottom -0
#base_bottom - .33
#top_bottom / bottom_top - 67 - avg
#base_top - what is found in txt file-1
#top_top 1.3
# find least of rgb val, div by 3 then sbutract / add r g and b by that val to get top_bottom / top_top
# establish this for each wav
# bottom - .67 - 1.3

# for a given wav, look through full file (every frame) and do a weighted avg of freq + ampl for each frame
# take the weighted avg and do a big avg, freq above this will be top top
# at the same time find the greatest amplit

# go frame by frame, find loudest freq - find ampli assoc w/ that freq - brigtness is a frac thing
    # ig find loudest freq in top freq + loudest freq in bottom freq?
    # for loop through frames
    # the freq thing is also a frac, top - ranges from r-.67 least val, g ... to r+1.3 least val...
    # write vals in respective files
# each frame - stored as like 123a123r123g123b
