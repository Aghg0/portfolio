import os
import scipy.io.wavfile as wavey
import serial
#from playsound import playsound
import time
import pyaudio
import wave

try:
  ser = serial.Serial('COM4', 115200)
except:
  try:
    ser = serial.Serial('COM3', 115200)
  except:
    pass

try:
  ser.write("s".encode('utf-8'))
  ard_ready =False
  while ard_ready == False:
      if ser.in_waiting > 0:
        print("ta")
        data = ser.read().decode()
        print(data)
        if data == "o":
          ard_ready = True 
except:
  pass


folder_path_os = "D:/Downloads/New folder (3)/song"# Replace with the actual path
global stop
stop= False

def run (item):

  global skip
  skip = False

  global pause
  pause = False

  file_harmonic = os.path.join("New folder (3)", "arduino_rgb",item.replace(".wav", "") + "harmonic.txt")
  #file_bottom = os.path.join("New folder (3)", "arduino_rgb",item.replace(".wav", "") + "bottom.txt")
  file_perc = os.path.join("New folder (3)", "arduino_rgb",item.replace(".wav", "") + "percussive.txt")

  ard_message = "begin"
  with open(file_harmonic, 'r') as top:
    lines = len(top.readlines())
    top.seek(0)
    print(lines)
  current_line = 1

  sampling_rate, audio_data = wavey.read("D:/Downloads/New folder (3)/song/"+item )
  chunk = round(sampling_rate / 15)
  # you audio here
  wf = wave.open("D:/Downloads/New folder (3)/song/"+item ,'rb')

  
  # instantiate PyAudio
  p = pyaudio.PyAudio()


  # open stream using callback
  stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                  channels=wf.getnchannels(),
                  rate=wf.getframerate(),
                  output=True)
  # start the stream
  data = wf.readframes(chunk)
  stream.start_stream()
  current_time = round(time.time() * 1000)
  while (data) and (stop == False) and (skip ==False):
    # writing to the stream is what *actually* plays the sound.
    try:
      ard_message = ""
      with open(file_harmonic, 'r') as top:
        for mm in range(current_line):
          add = (top.readline().strip('\n'))
        ard_message += str(add)
    # with open(file_bottom, 'r') as bottom:
    #   for mm in range(current_line):
    #    add = (bottom.readline().strip('\n'))
    #   ard_message += str(add)
      with open(file_perc, 'r') as perc:
        for mm in range(current_line):
          add = (perc.readline().strip('\n'))
        ard_message += str(add)
      current_line+=1
      print(ard_message)
      ser.write(ard_message.encode())
    except:
      pass
    stream.write(data)
    data = wf.readframes(chunk)
    while pause == True:
      pass
    

  stream.stop_stream()
  stream.close()
  wf.close()

  p.terminate()

#   ser.write("f".encode())

# for item in os.listdir(folder_path_os):
#    run(item)