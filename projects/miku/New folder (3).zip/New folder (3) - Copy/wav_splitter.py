import librosa
import numpy as np
import soundfile as sf

def wav_split(file_dir):
    # assuming file is the file path of the wav like D:/Downloads/senbonzakuramiku.wav
    y, sr = librosa.load(file_dir)
    y_harmonic, y_percussive = librosa.effects.hpss(y)
    slash_pos = len(file_dir)-file_dir[::-1].find("/")
    dot_pos = len(file_dir)-file_dir[::-1].find(".")-1
    name = file_dir[slash_pos:dot_pos]
    sf.write("D:/Downloads/New folder (3)/song_separate/"+name+"harmonic.wav", y_harmonic, sr)
    sf.write("D:/Downloads/New folder (3)/song_separate/"+name+"percussive.wav", y_percussive, sr)

# file_dir = "D:/Downloads/New folder (3)/song/gunjousanka.wav"
# wav_split(file_dir)