import urllib.request
import requests
from PIL import Image
import io
import re
import os
import math

def extract_src(filename):
    src = []
    images = []
    try:
        response = urllib.request.urlopen('https://www.google.com/search?client=firefox-b-1-d&sca_esv=8728115b13c098f3&q='+str(filename)+'&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBsxayPSIAqObp_AgjkUGqel3rTRMIJGV_ECIUB00muput9Zp8VMKUi0ZjqPs3JlrgPeFrAnFlUitTiL3WcJlFn10ZVAeuxL5fSn-ULNu9lz3DIW3cy7rkKNmgHapdAFAoBFSl5-LQE_swXRSgVvZGy87KiusPiw1DSGvVAMCLf6f2K4DEg&sa=X&ved=2ahUKEwiw6tCgrKuNAxWgFFkFHRaSGboQtKgLegQIGxAB&biw=1536&bih=827&dpr=1.25')
        html = response.read().decode('utf-8')
    except urllib.error.URLError as e:
        print(f"Error accessing URL: {e}")

    positions_src = [match.start() for match in re.finditer("alt=\"\" src=\"", html)]
    positions_quote = [match.start() for match in re.finditer("\"", html)]

    positions_src[0] += 11
    src.append((html[positions_src[0]+1:positions_quote[positions_quote.index(positions_src[0])+1]]).replace("&amp;s",""))
    return src

def src_to_color(src,filename):
    red = 0
    blue = 0
    green = 0
    count = 0
    red2=0
    green2=0
    blue2=0
    count2=0
    try:
        # Download the image
        response = requests.get(src[0], stream=True)
        response.raise_for_status()  # Raise an exception for bad status codes
        # open("D:/Downloads/New folder (3)/picture/"+filename+"_image", 'wb').write(response.content)
        # Open the image using Pillow
        image = Image.open(io.BytesIO(response.raw.read()))
        # Access pixel data (example: get the color of pixel at (100, 50))
        width, height = image.size
        for m in range(width):
            for n in range(height):
                pixel = image.getpixel((m, n))
                if pixel[0] < 30 and pixel[1] < 30 and pixel[2] < 30:
                    pass
                elif  pixel[0] > 200 and pixel[1] > 200 and pixel[2] > 200:
                    pass
                elif abs(pixel[0] - pixel[1]) < 20 and abs(pixel[0] - pixel[2]) < 20 and abs(pixel[2] - pixel[1] < 20):
                    pass
                else: 
                    red += pixel[0]
                    green += pixel[1]
                    blue += pixel[2]
                    count += 1
        image.save("D:/Downloads/New folder (3)/picture/"+filename+".jpg")
        image.close()
    except requests.exceptions.RequestException as e:
        print(f"Error downloading image: {e}")
    except Exception as e:
        print(f"Error processing image: {e}")
    red /= count
    blue /= count
    green /= count

    try:
        # Download the image
        response = requests.get(src[0], stream=True)
        response.raise_for_status()  # Raise an exception for bad status codes

        # Open the image using Pillow
        image = Image.open(io.BytesIO(response.raw.read()))

        # Access pixel data (example: get the color of pixel at (100, 50))
        width, height = image.size
        for m in range(width):
            for n in range(height):
                pixel = image.getpixel((m, n))
                if pixel[0] < 20 and pixel[1] < 20 and pixel[2] < 20:
                    pass
                elif  pixel[0] > 220 and pixel[1] > 220 and pixel[2] > 220:
                    pass
                elif math.sqrt((pixel[0]-red)**2+(pixel[1]-green)**2+(pixel[2]-blue)**2) < 70:
                    pass
                else: 
                    red2 += pixel[0]
                    green2 += pixel[1]
                    blue2 += pixel[2]
                    count2 += 1
        image.close()
    except requests.exceptions.RequestException as e:
        print(f"Error downloading image: {e}")
    except Exception as e:
        print(f"Error processing image: {e}")
    red2 /= count2
    green2 /= count2
    blue2 /= count2
    return red,green,blue,red2,green2,blue2

# folder_path_os = "D:/Downloads/New folder (3)/song"# Replace with the actual path
# for item in os.listdir(folder_path_os):
#     cnt = -1
#     perm_cnt = False
#     for o in reversed(item):
#         if not o.isalnum():
#             perm_cnt = True
#         if perm_cnt == False:
#             cnt -= 1
#     extension = item[cnt:]
#     filename = item.replace(extension, "")
#     file_path = os.path.join("New folder (3)", "miku_color_song",filename + ".txt")
#     src = extract_src(filename)
#     red,green,blue,red2,green2,blue2 = src_to_color(src,filename)

#     file_path = os.path.join("New folder (3)", "miku_color_song",filename + ".txt")
#     os.makedirs(os.path.dirname(file_path), exist_ok=True)
#     with open(file_path, "w") as file1:
#         file1.write(str(int(red))+"r"+str(int(green))+"g"+str(int(blue))+"b")
    
#     file_path2 = os.path.join("New folder (3)", "miku_color_song",filename+"2.txt")
#     os.makedirs(os.path.dirname(file_path2), exist_ok=True)
#     with open(file_path2, "w") as file2:
#         file2.write(str(int(red2))+"r"+str(int(green2))+"g"+str(int(blue2))+"b")
#     print("File created or overwritten successfully.")