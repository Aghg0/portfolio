import scipy.io.wavfile as wf
import scipy.fft as fft
import numpy as np
import math
import os
import statistics


def harmonic_to_rgbs(file_dir,fps):
    sampling_rate, audio_data = wf.read(file_dir)
    if audio_data.ndim == 2:  # Check if it's stereoh
        audio_mono = np.mean(audio_data, axis=1)
    else:
        audio_mono = audio_data  # Already mono

    big_fre =0
    small_fre = 900000
    freqs = []
    perc_dom_freq=[]
    perc_dom_amp=[]
    color_range = 40

    frames_per_second = round(sampling_rate / fps)
    for i in range(1,math.ceil(len(audio_mono)/frames_per_second)+1):
        try:
            audio_sample = audio_mono[int(frames_per_second*(i-1)):int(frames_per_second*i)]
        except:
            audio_sample = audio_mono[int(frames_per_second*(i-1)):]
        fft_result = fft.fft(audio_sample)
        fft_magnitude = np.abs(fft_result)
        fft_frequencies = fft.fftfreq(len(audio_sample), 1/sampling_rate)
        peak_index = np.argmax(fft_magnitude)  # Exclude DC component
        dominant_frequency = (fft_frequencies[peak_index])
        amp = fft_magnitude[np.argmax(fft_magnitude)]

        if dominant_frequency > 0:
            freqs.append(dominant_frequency)

        if dominant_frequency > big_fre:
            big_fre = dominant_frequency
        
        perc_freq = []
        perc_mag = []

        for index in range(fft_magnitude.size):
            if fft_magnitude[index]>=0: 
                perc_freq.append(fft_frequencies[index])
                perc_mag.append(fft_magnitude[index])

        perc_freq = np.array(perc_freq)
        perc_mag = np.array(perc_mag)



        perc_loud_fre = perc_freq[np.argmax(perc_mag)]
        perc_amp = perc_mag[np.argmax(perc_mag)]

        perc_dom_freq.append(perc_loud_fre)
        perc_dom_amp.append(perc_amp)


    base_fre = math.exp(0.061)

    red = 0
    green = 0
    blue = 0
    data = ""

    #"D:/Downloads/New folder (3)/song_separate/senbonzakuramikuharmonic.wav"

    slash_pos = len(file_dir)-file_dir[::-1].find("/")
    dot_pos = len(file_dir)-file_dir[::-1].find(".")-1
    name = file_dir[slash_pos:dot_pos-8]

    with open("D:/Downloads/New folder (3)/miku_color_song/" +  name + ".txt") as file1:
        color = file1.read()
        for p in color:
            if p == "r":
                red = data
                data = ""
            if p == "g":
                green = data
                data = ""
            if p == "b":
                blue = data
                data = ""
            if p.isdigit():
                data += p
        base_perc = [int(red),int(green),int(blue)]
        least = min(int(red),int(green),int(blue))
        most = max(int(red),int(green),int(blue))

        if least < color_range:
            alter = color_range - least
            base_perc = [x + alter if x+alter <= 255 else 255 for x in base_perc]
        elif most > 225:
            alter = 255-225
            base_perc = [x- alter if x - alter >= 0 else 0 for x in base_perc]

        perc_bottom = [math.ceil(x-color_range) if math.ceil(x-color_range) >=0 else 0 for x in base_perc]

    smmmm = 0

    #1,math.ceil(len(audio_mono)/1000)+1


    percentile = 1.5

    perc_dom_freq.sort()
    perc_temp = list(perc_dom_freq)
    perc_temp = [x for x in perc_dom_freq if x > 0]
    perc_small_fre = perc_temp[math.ceil(len(perc_temp)*percentile/100)]


    perc_dom_amp.sort()
    perc_temp = list(perc_dom_amp)
    perc_temp = [x for x in perc_temp if x > 0]
    perc_small_amp = perc_temp[math.ceil(len(perc_temp)*percentile/100)]

    # make temp lists, get rid of 0s, find 2nd percentile, set that to be bottom_small_amp etc


    perc_big_fre = max(perc_dom_freq)


    perc_small_fre_log = ((math.log(perc_small_fre,base_fre)-54.21)/0.95)
    perc_big_fre_log = ((math.log(perc_big_fre,base_fre)-54.21)/0.95)



    for i in range(1,math.ceil(len(audio_mono)/frames_per_second)+1):
        try:
            audio_sample = audio_mono[frames_per_second*(i-1):frames_per_second*i]
        except:
            audio_sample = audio_mono[frames_per_second*(i-1):]
        #print(audio_sample)
        fft_result = fft.fft(audio_sample)
        fft_magnitude = np.abs(fft_result)
        fft_frequencies = fft.fftfreq(len(audio_sample), 1/sampling_rate)

        perc_freq = []
        perc_mag = []


        for index in range(fft_magnitude.size):
            perc_freq.append(fft_frequencies[index])
            perc_mag.append(fft_magnitude[index])
    
        perc_freq = np.array(perc_freq)
        perc_mag = np.array(perc_mag)

        perc_loud_fre = perc_freq[np.argmax(perc_mag)]
        perc_amp = perc_mag[np.argmax(perc_mag)]


        if perc_amp < perc_small_amp:
            rgb_frame_perc = [0,0,0]
            perc_loud_fre_log = -32
        elif perc_loud_fre == 0:
            rgb_frame_perc = [0,0,0]   
            perc_loud_fre_log = -32
        else:
            perc_loud_fre_log = ((math.log(perc_loud_fre,base_fre)-54.21)/0.95)
            rgb_frame_perc = [math.ceil(x+(2*color_range)*((perc_loud_fre_log-perc_small_fre_log)/(perc_big_fre_log-perc_small_fre_log))) if math.ceil(x+(2*color_range)*((perc_loud_fre_log-perc_small_fre_log)/(perc_big_fre_log-perc_small_fre_log))) <= 255 else 255 for x in perc_bottom]
            #print(top_big_fre_log-top_small_fre_log)
    #fix rgb_frame

        red_perc = rgb_frame_perc[0]
        green_perc = rgb_frame_perc[1]
        blue_perc = rgb_frame_perc[2]

        file_path = os.path.join("New folder (3)", "arduino_rgb", name +"harmonic.txt")
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        if i == math.ceil(len(audio_mono)/frames_per_second):
            with open(file_path, "a") as file1:
                file1.write(str(red_perc)+"b"+str(green_perc)+"c"+str(blue_perc)+"d")
        else:
            with open(file_path, "a") as file1:
                file1.write(str(red_perc)+"b"+str(green_perc)+"c"+str(blue_perc)+"d" +"\n")



    # make new fn for percssion prposes

    # # make new fn for percssion prposes
    # make that generalized

#


def percussive_to_rgbs(file_dir,fps):
    sampling_rate, audio_data = wf.read(file_dir)
    if audio_data.ndim == 2:  # Check if it's stereoh
        audio_mono = np.mean(audio_data, axis=1)
    else:
        audio_mono = audio_data  # Already mono

    temp=0
    sum = 0
    m = 0
    big_fre =0
    small_fre = 900000
    small_amp = 900000
    freqs = []
    perc_dom_freq=[]
    perc_dom_amp=[]
    color_range = 40
  

    frames_per_second = round(sampling_rate / fps)
    for i in range(1,math.ceil(len(audio_mono)/frames_per_second)+1):
        try:
            audio_sample = audio_mono[int(frames_per_second*(i-1)):int(frames_per_second*i)]
        except:
            audio_sample = audio_mono[int(frames_per_second*(i-1)):]
        fft_result = fft.fft(audio_sample)
        fft_magnitude = np.abs(fft_result)
        fft_frequencies = fft.fftfreq(len(audio_sample), 1/sampling_rate)
        peak_index = np.argmax(fft_magnitude)  # Exclude DC component
        dominant_frequency = (fft_frequencies[peak_index])
        amp = fft_magnitude[np.argmax(fft_magnitude)]

        if dominant_frequency > 0:
            freqs.append(dominant_frequency)
        if dominant_frequency > big_fre:
            big_fre = dominant_frequency
        
        perc_freq = []
        perc_mag = []

        for index in range(fft_magnitude.size):
            if fft_magnitude[index]>=0: 
                perc_freq.append(fft_frequencies[index])
                perc_mag.append(fft_magnitude[index])

        perc_freq = np.array(perc_freq)
        perc_mag = np.array(perc_mag)



        perc_loud_fre = perc_freq[np.argmax(perc_mag)]
        perc_amp = perc_mag[np.argmax(perc_mag)]

        perc_dom_freq.append(perc_loud_fre)
        perc_dom_amp.append(perc_amp)


    base_fre = math.exp(0.0586)


    red = 0
    green = 0
    blue = 0
    data = ""

    #"D:/Downloads/New folder (3)/song_separate/senbonzakuramikuharmonic.wav"

    slash_pos = len(file_dir)-file_dir[::-1].find("/")
    dot_pos = len(file_dir)-file_dir[::-1].find(".")-1
    name = file_dir[slash_pos:dot_pos-10]

    with open("D:/Downloads/New folder (3)/miku_color_song/" +  name + "2.txt") as file1:
        color = file1.read()
        for p in color:
            if p == "r":
                red = data
                data = ""
            if p == "g":
                green = data
                data = ""
            if p == "b":
                blue = data
                data = ""
            if p.isdigit():
                data += p
        base_perc = [int(red),int(green),int(blue)]
        least = min(int(red),int(green),int(blue))
        most = max(int(red),int(green),int(blue))

        

        if least < color_range:
            alter = color_range - least
            base_perc = [x + alter if x+alter <= 255 else 255 for x in base_perc]
        elif most > 225:
            alter = 255-225
            base_perc = [x- alter if x - alter >= 0 else 0 for x in base_perc]

        perc_bottom = [math.ceil(x-color_range) if math.ceil(x-color_range) >=0 else 0 for x in base_perc]

    smmmm = 0

    #1,math.ceil(len(audio_mono)/1000)+1


    percentile = 1.5

    perc_dom_freq.sort()
    perc_temp = list(perc_dom_freq)
    perc_temp = [x for x in perc_dom_freq if x > 0]
    perc_small_fre = perc_temp[math.ceil(len(perc_temp)*percentile/100)]


    perc_dom_amp.sort()
    perc_temp = list(perc_dom_amp)
    perc_temp = [x for x in perc_temp if x > 0]
    perc_small_amp = perc_temp[math.ceil(len(perc_temp)*percentile/100)]

    # make temp lists, get rid of 0s, find 2nd percentile, set that to be bottom_small_amp etc


    perc_big_fre = max(perc_dom_freq)


    perc_small_fre_log = ((math.log(perc_small_fre,base_fre)-54.21)/0.95)
    perc_big_fre_log = ((math.log(perc_big_fre,base_fre)-54.21)/0.95)



    for i in range(1,math.ceil(len(audio_mono)/frames_per_second)+1):
        try:
            audio_sample = audio_mono[frames_per_second*(i-1):frames_per_second*i]
        except:
            audio_sample = audio_mono[frames_per_second*(i-1):]
        #print(audio_sample)
        fft_result = fft.fft(audio_sample)
        fft_magnitude = np.abs(fft_result)
        fft_frequencies = fft.fftfreq(len(audio_sample), 1/sampling_rate)

        perc_freq = []
        perc_mag = []


        for index in range(fft_magnitude.size):
            perc_freq.append(fft_frequencies[index])
            perc_mag.append(fft_magnitude[index])
    
        perc_freq = np.array(perc_freq)
        perc_mag = np.array(perc_mag)

        perc_loud_fre = perc_freq[np.argmax(perc_mag)]
        perc_amp = perc_mag[np.argmax(perc_mag)]


        if perc_amp < perc_small_amp:
            perc_bright = 0
            rgb_frame_perc = [0,0,0]
        elif perc_loud_fre == 0:
            perc_bright = 0
            rgb_frame_perc = [0,0,0]   
        else:

            perc_loud_fre_log = ((math.log(perc_loud_fre,base_fre)-54.21)/0.95)
            rgb_frame_perc = [math.ceil(x+(2*color_range)*((perc_loud_fre_log-perc_small_fre_log)/(perc_big_fre_log-perc_small_fre_log))) if math.ceil(x+(2*color_range)*((perc_loud_fre_log-perc_small_fre_log)/(perc_big_fre_log-perc_small_fre_log))) <= 255 else 255 for x in perc_bottom]
            #print(top_big_fre_log-top_small_fre_log)
    #fix rgb_frame

        red_perc = rgb_frame_perc[0]
        green_perc = rgb_frame_perc[1]
        blue_perc = rgb_frame_perc[2]

        file_path = os.path.join("New folder (3)", "arduino_rgb", name +"percussive.txt")
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        if i == math.ceil(len(audio_mono)/frames_per_second):
            with open(file_path, "a") as file1:
                file1.write(str(red_perc)+"j"+str(green_perc)+"k"+str(blue_perc)+"l")
        else:
            with open(file_path, "a") as file1:
                file1.write(str(red_perc)+"j"+str(green_perc)+"k"+str(blue_perc)+"l" +"\n")

    # make new fn for percssion prposes
    # make that generalized

#harmonic_to_rgbs("D:/Downloads/New folder (3)/song_separate/senbonzakuramikuharmonic.wav")
#percussive_to_rgbs("D:/Downloads/New folder (3)/song_separate/senbonzakuramikupercussive.wav")

# folder_path_os = "D:/Downloads/New folder (3)/song"# Replace with the actual path
# for item in os.listdir(folder_path_os):
#     cnt = -1
#     perm_cnt = False
#     for o in reversed(item):
#         if not o.isalnum():
#             perm_cnt = True
#         if perm_cnt == False:
#             cnt -= 1
#     extension = item[cnt:]
#     filename = item.replace(extension, "")
#     harmonic_to_rgbs("D:/Downloads/New folder (3)/song_separate/"+filename+"harmonic.wav",15)
#     percussive_to_rgbs("D:/Downloads/New folder (3)/song_separate/"+filename+"percussive.wav",15)