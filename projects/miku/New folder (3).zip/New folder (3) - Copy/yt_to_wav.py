from yt_dlp import YoutubeDL
import os
import moviepy

def download_youtube_content(url,name):
    os.makedirs("D:/Downloads/New folder (3)", exist_ok=True)

    format_selector = (
        'bestvideo[height<=1080]+bestaudio/best[height<=1080]/'
        'best'
    )
    ydl_opts = {
        'format': format_selector,
        'merge_output_format': 'mp4',
        'ignoreerrors': True,
        'no_warnings': False,
        'extract_flat': False,
        'writesubtitles': False,
        'writethumbnail': False,
        'writeautomaticsub': False,
        'postprocessors': [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': 'mp4',
        }],
        'keepvideo': False,
        'clean_infojson': True,
        'retries': 3,
        'fragment_retries': 3,
    }
    ydl_opts['outtmpl'] = os.path.join("D:/Downloads/New folder (3)", '%(title)s.%(ext)s')
    
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    for item in os.listdir("D:/Downloads/New folder (3)"):
        if os.path.splitext(item)[1] ==".webm":
            try:
                clip = moviepy.AudioFileClip("D:/Downloads/New folder (3)/"+ item)
                clip.write_audiofile("D:/Downloads/New folder (3)/song/"+name+".wav")
            except:
                pass
    for item in os.listdir("D:/Downloads/New folder (3)"):
        if os.path.splitext(item)[1] ==".webm" or os.path.splitext(item)[1]== ".mp4":
            os.remove("D:/Downloads/New folder (3)/"+item)


# download_youtube_content("https://www.youtube.com/watch?v=zRzdoTKRp-s","gunjou_sanka")

# #https://github.com/pH-7/Download-Simply-Videos-From-YouTube/blob/main/download.py